/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.employeemanagermain;

/**
 *
 * @author hp
 */
public class EmployeeManagerMain {

    public static void main(String[] args) {
        Manager manager=new Manager("Eeman",2000,"CyberSecurity");
        manager.displayInfo();
        manager.display();
        
    }
}
